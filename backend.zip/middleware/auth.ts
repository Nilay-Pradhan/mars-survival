import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import 'dotenv/config';
import { user } from '../src/settings/_validation';


export const auth = async (req: Request, res: Response, next: NextFunction) => {
   try {
      const token: string = req.headers['x-auth-token'] as string;
      if (!token) return res.status(401).json({ message: "Authentication failed!" });

      let jwtSecret: any = process.env.JWT_SECRET;
      const decodedToken: any = jwt.verify(token, jwtSecret);
      let exp = decodedToken.exp * 1000;
      let iat = decodedToken.iat * 1000;
      console.log("decodedToken", decodedToken, "expire_at");
      console.log("expire_at", new Date(exp).toUTCString(), "issued_at", new Date(iat).toUTCString());
      let _cid: string = decodedToken._cid;

      let _user: any = await user.findOne({ _id: _cid, status: 1 });
      if (!_user) return res.status(401).json({ message: "Authentication failed!" });
      req.body._cid = _cid;
      next();
   } catch (error) {
      return res.status(401).json({ message: "Authentication failed!!!" });
   }
};