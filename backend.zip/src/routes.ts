import express from 'express';
// import { auth } from '../middleware/auth';

import ration from '../src/ration/_route';
import user from '../src/user/_route';


const app = express();

app.use('/ration', ration);
app.use('/user', user);


export default app;