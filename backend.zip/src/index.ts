import express from 'express';
import db from '../startup/db';
import errorHandler from '../startup/error';
import models from '../startup/models';
import router from '../startup/router';
import 'dotenv/config';

const app = express();

db();
models();
router(app);
errorHandler();

const port = process.env.PORT;

app.listen(port, () => console.log(`connnected on port ${port}`));

