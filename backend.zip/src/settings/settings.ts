import { Request, Response } from 'express';
import { user, validateUpdatePin } from './_validation';
import _ from 'lodash';


export const updatePin = async (req: Request, res: Response) => {
    const { error } = validateUpdatePin(req.body);
    if (error) throw error;

    let customer: any = await user.findOne({ _id: req.body._cid });
    if (!customer) return res.status(400).json({ message: "No record found." });
    if (customer.mpin != req.body.old_pin) return res.status(400).json({ message: "Old Pin not matched." });

    customer.mpin = req.body.new_pin;
    customer = await customer.save();
    res.status(200).json({ message: "New Pin updated successfully." });
};