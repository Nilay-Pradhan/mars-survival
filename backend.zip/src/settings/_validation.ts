import { model } from "mongoose";
import { userSchema } from "../../models/user";

import Joi from 'joi';

export const user = model('user', userSchema);

export const validatePin = (data: any) => {
    const schema = Joi.object({
        mpin: Joi.string().required().label('Pin')
    });

    return schema.validate(data, { abortEarly: false, allowUnknown: true });
};

export const validateUpdatePin = (data: any) => {
    const schema = Joi.object({
        old_pin: Joi.string().required().label('Old Pin'),
        new_pin: Joi.string().required().label('New Pin')
    });

    return schema.validate(data, { abortEarly: false, allowUnknown: true });
};

export const validateUpdateInteracId = (data: any) => {
    const schema = Joi.object({
        id: Joi.string().required().label('Id'),
        currency_code: Joi.string().required().label('Currency Code'),
        interac_id: Joi.string().required().label('Interac Id')
    });

    return schema.validate(data, { abortEarly: false, allowUnknown: true });
};