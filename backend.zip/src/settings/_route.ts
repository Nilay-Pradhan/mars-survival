import { Router } from "express";
import { auth } from "../../middleware/auth";
import { updatePin } from "./settings";
const router = Router();

router.post('/update_pin', auth, updatePin);

export default router;