import { Router } from "express";
import {getAllUsers, registerUser, getUser, updateUser, deleteUser} from "./user";
const router = Router();

router.post('/getAllUsers', getAllUsers);
router.post('/registerUser', registerUser);
router.post('/getUser', getUser);
router.post('/updateUser', updateUser);
router.post('/deleteUser', deleteUser);

export default router;