import { model } from "mongoose";
import mongoose from "mongoose";
import { userSchema } from "../../models/user";

import Joi from 'joi';
export const User = model('User', userSchema);

export const validateGetAllUsers = (data: any) => {
    const schema = Joi.object({

    })
    return schema.validate(data, { abortEarly: false, allowUnknown: true });
}
export const validateRegisterUser = (data: any) => {

    let validObjectId = mongoose.Types.ObjectId.isValid(data.country).toString();
    const schema = Joi.object({
        fullname: Joi.string().label('fullname'),
        email_id: Joi.string().label('email_id'),
        address: Joi.string().label('address'),
        city: Joi.string().label('city'),
        postal_code: Joi.string().label('postal_code'),
        state: Joi.string().label('state'),
        country : Joi.string().when(validObjectId, { is: true, then: Joi.string().required() }).label('Country'),
        country_code: Joi.number().label('country_code'),
        mobile_no: Joi.string().label('mobile_no'),
        mpin: Joi.string().label('mpin'),
        otp: Joi.number().label('otp'),
        unique_id: Joi.number().label('unique_id'),
        inr_wallet_balance: Joi.number().label('inr_wallet_balance'),
        reference_id: Joi.string().empty('').label('reference_id'),
        referred_id: Joi.string().empty('').label('referred_id'),
        kyc_type: Joi.number().label('kyc_type'),
        kyc_created_at: Joi.date().empty('').greater('06-01-2022'),
        kyc_status: Joi.number().label('kyc_status'),
        sumsub_reference_id: Joi.string().empty('').label('sumsub_reference_id'),
        last_login_date_time: Joi.date().greater('06-01-2022'),
        status: Joi.number().label('status'),
        created_at: Joi.date().greater('06-01-2022'),
        updated_at: Joi.date().greater('06-01-2022')
    })
    return schema.validate(data, { abortEarly: false, allowUnknown: true });
}

export const validateGetUser = (data: any) => {
    const schema = Joi.object({
        mobile_no: Joi.string().required().label('mobile_no is required')
    })
    return schema.validate(data, { abortEarly: false, allowUnknown: true });
}

export const validateUpdateUser = (data: any) => {
    let validObjectId = mongoose.Types.ObjectId.isValid(data.country).toString();
    const schema = Joi.object({
        fullname: Joi.string().label('fullname'),
        email_id: Joi.string().label('email_id'),
        address: Joi.string().label('address'),
        city: Joi.string().label('city'),
        postal_code: Joi.string().label('postal_code'),
        state: Joi.string().label('state'),
        country : Joi.string().when(validObjectId, { is: true, then: Joi.string().required() }).label('Country'),
        country_code: Joi.number().label('country_code'),
        mobile_no: Joi.string().label('mobile_no'),
        mpin: Joi.string().label('mpin'),
        otp: Joi.number().label('otp'),
        unique_id: Joi.number().label('unique_id'),
        inr_wallet_balance: Joi.number().label('inr_wallet_balance'),
        reference_id: Joi.string().empty('').label('reference_id'),
        referred_id: Joi.string().empty('').label('referred_id'),
        kyc_type: Joi.number().valid(1, 2).label('kyc_type'), // (1:Manual, 2:Auto)
        kyc_created_at: Joi.date().empty('').greater('06-01-2022'),
        kyc_status: Joi.number().valid(1, 2, 3).label('kyc_status'), // (1:Pending, 2:Verified, 3:Rejected)
        sumsub_reference_id: Joi.string().empty('').label('sumsub_reference_id'),
        last_login_date_time: Joi.date().greater('06-01-2022'),
        status: Joi.number().valid(1,2).label('status'), // (1:Enable, 2:Disable)
        created_at: Joi.date().greater('06-01-2022'),
        updated_at: Joi.date().greater('06-01-2022')
    })
    return schema.validate(data, { abortEarly: false, allowUnknown: true });
}

export const validateDeleteUser = (data: any) => {
    const schema = Joi.object({
        mobile_no: Joi.string().required().label('mobile_no is required')
    })
    return schema.validate(data, { abortEarly: false, allowUnknown: true });
}