import { Request, Response } from 'express';
import { User, validateRegisterUser, validateGetUser, validateUpdateUser, validateDeleteUser} from './_validation';
import _ from 'lodash';

export const getAllUsers = async (req: Request, res: Response) => {
    let pageNumber: number = req.body.pageNumber ?? 0;
    let nPerPage: number = req.body.nPerPage ?? 20;
    
    let all_user: any = await User.find({})
                                    .populate('country')    
                                    .skip(pageNumber > 0 ? ( pageNumber - 1 ) * nPerPage : 0)
                                    .limit(nPerPage);
    if (!all_user) return res.status(400).send({success: false, message: 'User not found! something went wrong' });

    res.status(200).send({success: true, data: all_user});
};

export const registerUser = async (req: Request, res: Response) => {
    const { error } = validateRegisterUser(req.body);
    if (error) throw error;
    
    let user: any = await User.findOne({mobile_no: req.body.mobile_no})
    let payload: any = _.pick(req.body, [
        "fullname",
        "email_id",
        "address",
        "city",
        "postal_code",
        "state",
        "country",
        "country_code",
        "mobile_no",
        "mpin",
        "otp",
        "unique_id",
        "inr_wallet_balance",
        "reference_id",
        "referred_id",
        "kyc_type",
        "kyc_created_at",
        "kyc_status",
        "sumsub_reference_id",
        "last_login_date_time",
        "status",
    ]);
    payload.created_at; new Date();
    payload.updated_at; new Date();
    console.log("user", user, "payload", payload);
    
    if (!user){
        let register: any = new User(payload);
        register = await register.save();
        
        if (!register) return res.status(400).send({success: false, message: 'User not found! something went wrong' });
        res.status(200).send({success: true, data: payload});
    }else{
        res.status(400).send({success: false, message: `User with mobile number ${user.mobile_no} already exist`});
    }

};

export const getUser = async (req: Request, res: Response) => {
    const { error } = validateGetUser(req.body);
    if (error) throw error;

    let user: any = await User.findOne({ mobile_no: req.body.mobile_no }).populate('country');
    if (!user) {
        res.status(400).send({success: false, message: `User with mobile number ${req.body.mobile_no} not found!`});
    }
    res.status(200).send({success: true, data: user });
};

export const updateUser = async (req: Request, res: Response) => {
    const { error } = validateUpdateUser(req.body);
    if (error) throw error;
    
    let payload: any = _.pick(req.body, [
        "fullname",
        "email_id",
        "address",
        "city",
        "postal_code",
        "state",
        "country",
        "country_code",
        "mobile_no",
        "mpin",
        "otp",
        "unique_id",
        "inr_wallet_balance",
        "reference_id",
        "referred_id",
        "kyc_type",
        "kyc_created_at",
        "kyc_status",
        "sumsub_reference_id",
        "last_login_date_time",
        "status",
        "created_at"
    ]);
    payload.updated_at; new Date();
    let user: any = await User.updateOne({ mobile_no: req.body.mobile_no }, payload);
    console.log("user", user, "payload", payload);
    if (user.modifiedCount === 0) return res.status(400).send({success: false, message: `User with mobile number ${ req.body.mobile_no } not updated!` });
        res.status(200).send({success: true, data: payload});
};

export const deleteUser = async (req: Request, res: Response) => {
    const { error } = validateDeleteUser(req.body);
    if (error) throw error;

    let user: any = await User.deleteOne({ mobile_no: req.body.mobile_no });
    console.log('user', user);
    if (user.deletedCount === 0) return res.status(400).send({success: false,  message: `user with mobile number ${req.body.mobile_no} not deleted!` });

    res.status(200).send({success: true, message: `user with mobile number ${req.body.mobile_no} deleted successfully` });
};